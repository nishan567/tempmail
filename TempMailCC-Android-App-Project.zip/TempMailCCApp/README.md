# TempMail.cc Android app wrapper

This Android Studio project creates a small Android application that opens https://www.tempemail.cc/ in a full-screen WebView. It uses the site's own interface and mailbox behavior, rather than an unverified third-party API implementation.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `TempMailCCApp` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- Internet access is required.
- Mailbox creation, inbox refresh, and OTP behavior are provided by TempMail.cc itself; this wrapper does not bypass provider limits.
- This is Android Studio source, not a prebuilt APK. Building requires Android SDK/Gradle tooling.
